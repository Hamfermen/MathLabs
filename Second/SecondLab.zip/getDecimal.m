function [y] = getDecimal(A)
    y = A - fix(A);
end

