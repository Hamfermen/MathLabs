close all;
clear all;
clc;

n = 500;

M(n)
only_sin(n)
only_cos(n)

n = 50;

M(n)
only_sin(n)
only_cos(n)

n = 5;

M(n)
only_sin(n)
only_cos(n)

close all;